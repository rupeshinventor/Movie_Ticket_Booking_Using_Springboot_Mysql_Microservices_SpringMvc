package com.ltts.SpringWebApplication.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Ticket {

	@Id
	@GeneratedValue
	private int ticketId;
	private String email;
	private int movieId;
	private LocalDate bookingDate;
	private LocalTime showTime;
	private LocalDate showDate;
	private int quantity;
	private String ticketType;
	private int totalAmount;
	
	
	public Ticket() {
		super();
	}
	public Ticket(int ticketId, String email, int movieId, LocalDate bookingDate, LocalTime showTime,
			LocalDate showDate, int quantity,String ticketType,int totalAmount) {
		super();
		this.ticketId = ticketId;
		this.email = email;
		this.movieId = movieId;
		this.bookingDate = bookingDate;
		this.showTime = showTime;
		this.showDate = showDate;
		this.quantity = quantity;
		this.ticketType=ticketType;
		this.totalAmount = totalAmount;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public LocalDate getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}
	public LocalTime getShowTime() {
		return showTime;
	}
	public void setShowTime(LocalTime showTime) {
		this.showTime = showTime;
	}
	public LocalDate getShowDate() {
		return showDate;
	}
	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getTicketType() {
		return ticketType;
	}
	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "Ticket ticketId=" + ticketId + ", email=" + email + ", movieId=" + movieId + ", bookingDate="
				+ bookingDate + ", showTime=" + showTime + ", showDate=" + showDate + ", quantity=" + quantity
				+ ", ticketType=" + ticketType + ", totalAmount=" + totalAmount ;
	}
	
	
	
	
}
