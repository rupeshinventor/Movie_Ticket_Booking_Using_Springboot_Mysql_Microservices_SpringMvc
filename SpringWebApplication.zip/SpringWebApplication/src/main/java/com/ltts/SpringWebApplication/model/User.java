package com.ltts.SpringWebApplication.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
	private String username;
	private String mobile;
	
	@Id
	private String email;
	private String address;
	private String gender;
	private String usertype;
	
	public User() {
		super();
	}
	public User(String username, String mobile, String email, String address, String gender, String usertype) {
		super();
		this.username = username;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		this.gender = gender;
		this.usertype = usertype;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	@Override
	public String toString() {
		return "User username=" + username + ", mobile=" + mobile + ", email=" + email + ", address=" + address
				+ ", gender=" + gender + ", usertype=" + usertype;
	}
	
}
