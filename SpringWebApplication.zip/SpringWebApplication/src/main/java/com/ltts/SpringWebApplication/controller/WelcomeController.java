package com.ltts.SpringWebApplication.controller;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ltts.SpringWebApplication.Bo.MovieBo;
import com.ltts.SpringWebApplication.Bo.TicketBo;
import com.ltts.SpringWebApplication.Bo.UserBo;
import com.ltts.SpringWebApplication.model.Movie;
import com.ltts.SpringWebApplication.model.Ticket;
import com.ltts.SpringWebApplication.model.User;




@RestController
public class WelcomeController {
	
	@Autowired
	UserBo ub;
	@Autowired
	MovieBo mb;
	
	@Autowired
	TicketBo tb;
	
	@RequestMapping("/")
	public ModelAndView m1() {
		return new ModelAndView("index");
		}
	@RequestMapping("/register")
	public ModelAndView m2() {
		return new ModelAndView("register");
	}
	
	@RequestMapping(value="insertuser", method=RequestMethod.POST)
	public ModelAndView m3(HttpServletRequest req)throws Exception {
		ModelAndView mv=null;
		String name=req.getParameter("uname");
		
		
		
		System.out.println(name);
		String mobile=req.getParameter("mobile");
		String email=req.getParameter("email");
		String gender=req.getParameter("gender");
		String addr=req.getParameter("addr");
		
		//public User(String userName, String mobile, String email, String address, String gender, String userType); 
		User u=new User(name,mobile,email,addr,gender,"User");
		System.out.println(u);
		ub.save(u);
		System.out.println("Value inserted...");
		
		return mv;
	}
	@RequestMapping("/login")
	public ModelAndView m4()
	{
		return new ModelAndView("login");
	}
	@RequestMapping(value="checkuser", method=RequestMethod.POST)
	public ModelAndView m5(HttpServletRequest req,Model model,HttpSession session ) {
		ModelAndView mv=new ModelAndView("Success");;
		String username=req.getParameter("email");
		String pass=req.getParameter("pass");
		User u=ub.getById(username);
		System.out.println(u);
		if(u.equals(null))
		  {
   			model.addAttribute("msg","Username is wrong!!!!!");
		 	mv=new ModelAndView("Login");
		  }
       else {
          if(username.equals(u.getEmail()))
           {	
            if(pass.equals(u.getMobile()))
			{
			model.addAttribute("msg",u.getUsername());
			req.getSession().setAttribute("username", u.getEmail());
			mv=new ModelAndView("welcome");
			}
		else
			{
			model.addAttribute("msg","Your Password is Wrong!!!");
			mv=new ModelAndView("Login");
			}
           }
          else
          {
        	  model.addAttribute("msg","Username is wrong!!!!!");
  		 	mv=new ModelAndView("Login");
          }
       }
		return mv;
          
	}
	
	@RequestMapping("/addmovie")
	public ModelAndView m6()
	{
		return new ModelAndView("addmovie");
	}
	@RequestMapping(value="insertmovie",method=RequestMethod.POST)
	public ModelAndView m7(HttpServletRequest req) throws Exception
	{
		ModelAndView mv=new ModelAndView("Success");
		String name=req.getParameter("mname");
		String lang=req.getParameter("lang");
		LocalDate ld=LocalDate.parse(req.getParameter("releasedate"));
		String dir=req.getParameter("director"); 
		Movie m=new Movie(0,name,lang,ld,dir);
		boolean b=mb.insertMovie(m);
		return mv;
	}
	

	@RequestMapping("/viewmovies")
	public ModelAndView m8(HttpServletRequest req,Model model) throws Exception
	{
		ModelAndView mv = new ModelAndView("viewmovies");
		String lang=req.getParameter("lang");
		
		List<Movie> li=mb.getAllMovies();
		System.out.println(li);
		model.addAttribute("movies",li);
		
		return mv;
		
	}
	@RequestMapping("/Moviebylang")
	public ModelAndView m9(HttpServletRequest req, Model model) throws Exception
	{
		
		ModelAndView mv = new ModelAndView("Moviebylang");
		String lang=req.getParameter("lang");
		System.out.println("&&&&& ---- "+lang);
		List<Movie> li=mb.getMovieByLanguage(lang);
		System.out.println(li);
		model.addAttribute("movies",li);
		
		return mv;
		
	}
	@RequestMapping("/bookticket")
	public ModelAndView m9(Model model,HttpServletRequest req)
	{
		ModelAndView mv=new ModelAndView("bookticket");
		int id=Integer.parseInt(req.getParameter("id"));
		model.addAttribute("movieid",id);
		String username=req.getParameter("username");
		model.addAttribute("username", username);
		System.out.println("Id: "+id+" EMAIL: "+username);
		String name=(String) req.getSession().getAttribute("username");
		return mv;
	}
	
	
	@RequestMapping(value="insertticket", method=RequestMethod.POST)
	public ModelAndView m10(Model model,HttpServletRequest req)throws Exception {
		ModelAndView mv=null;
		String name=req.getParameter("username");
		int mid=Integer.parseInt(req.getParameter("mid"));
		String showdate=req.getParameter("showdate");
		String showtime=req.getParameter("showtime");
		
		int qty=Integer.parseInt(req.getParameter("qty"));
		String tickettype=req.getParameter("tickettype");
		// System.out.println(tickettype);
		int totalamount=0;
		
		if(tickettype.equals("platinum"))
		{
			totalamount=qty*250;
		}
		else if(tickettype.equals("economy"))
		{
			totalamount=qty*150;
		}
		else {
			totalamount=0;
		     }
		Ticket t=new Ticket(0,name,mid,LocalDate.now(),LocalTime.parse(showtime),LocalDate.parse(showdate),qty,tickettype,totalamount);
		
		List<Ticket> li=tb.findAll();
		int totalseat=0;
		for(Ticket t2:li)
		{
			if(LocalDate.parse(showdate).equals(t2.getShowDate()))
			{
				if(LocalTime.parse(showtime).equals(t2.getShowTime()))
				{
					if(t2.getMovieId()==mid)
					{
						totalseat=totalseat+t2.getQuantity();
					}
				}
			}
		}
		if(totalseat>=500)
		{
			// System.out.println("HOUSE FULL");
			mv=new ModelAndView("housefull");
			
		}
		else if(totalseat<500)
		{
			int availableseat=totalseat+qty;
			//496+6
			//502
			if(availableseat>500)
			{
				mv=new ModelAndView("housefull");
				int rem=availableseat-500;
				model.addAttribute("msg1","You ticket reached Maximum enter less than"+rem);
				model.addAttribute("ms2","You rae eligible to book"+(qty-rem));
				
				
			}
			else if(availableseat<=500)
			{
				mv=new ModelAndView("successbooking");
				model.addAttribute("amount",+totalamount);
				Ticket t1=tb.save(t);
			}
			else {
				
			}
		}
		return mv;
		
		//System.out.println(t1);
		
		
		
	}
}