package com.ltts.SpringWebApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.SpringWebApplication.Bo.MovieBo;
import com.ltts.SpringWebApplication.model.Movie;

@RestController
public class RemoteController {
@Autowired
MovieBo mb;
@GetMapping("/movies")
public List<Movie> getAllMovies() throws Exception {
	return mb.getAllMovies();
}
@GetMapping("/movies/{id}")
public Movie getMovieById(@PathVariable int id)throws Exception
{
	return mb.getMovieById(id);
}
@PostMapping("/movie")
public boolean postMovie(Movie m)throws Exception
{
	return mb.insertMovie(m);
	
}
@PutMapping("/movie")
public boolean updateMovie(Movie m)throws Exception
{
	return mb.updateMovie(m);
}
}
