package com.ltts.SpringWebApplication.Bo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.SpringWebApplication.model.Ticket;

public interface TicketBo extends JpaRepository<Ticket,Integer>
{

	
}
