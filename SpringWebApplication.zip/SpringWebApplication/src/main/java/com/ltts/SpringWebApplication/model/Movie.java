package com.ltts.SpringWebApplication.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity

public class Movie {
	@Id
	@GeneratedValue
	private int movieId;
	private String movieName;
	private String language;
	private LocalDate releaseDate;
	private String Director;
	
	public Movie(int movieId, String movieName, String language, LocalDate releaseDate, String director) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.language = language;
		this.releaseDate = releaseDate;
		this.Director = director;
	}
	
	public Movie() {
		super();
	}

	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public LocalDate getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getDirector() {
		return Director;
	}
	public void setDirector(String director) {
		Director = director;
	}

	@Override
	public String toString() {
		return "Movie movieId=" + movieId + ", movieName=" + movieName + ", language=" + language + ", releaseDate="
				+ releaseDate + ", Director=" + Director;
	}
	
	
	

}
