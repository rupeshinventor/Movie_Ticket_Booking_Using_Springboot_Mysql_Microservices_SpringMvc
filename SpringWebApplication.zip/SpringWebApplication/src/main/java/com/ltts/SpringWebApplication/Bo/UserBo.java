package com.ltts.SpringWebApplication.Bo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltts.SpringWebApplication.model.User;

@Repository
public interface UserBo extends JpaRepository<User,String> {

}
