package com.ltts.SpringWebApplication.Bo;

import java.util.List;

import javax.websocket.Session;

import org.hibernate.SessionFactory;
import org.hibernate.SharedSessionContract;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ltts.SpringWebApplication.model.Ticket;

@Repository
public class TicketBillBo {
	
	
		@Autowired
		SessionFactory sf;
		public boolean insertticket(Ticket t)throws Exception
		{
			Session s=(Session) sf.openSession();
			((SharedSessionContract) s).beginTransaction();
			((org.hibernate.Session) s).save(t);
			((SharedSessionContract) s).getTransaction().commit();
			s.close();
			return false;
		}
		public List<Ticket> getTicketDetails()throws Exception
		{
			List<Ticket> li=null;
		
			Session s=(Session) sf.openSession();
			((SharedSessionContract) s).beginTransaction();
			li=((SharedSessionContract) s).createCriteria(Ticket.class).list();
			((SharedSessionContract) s).getTransaction().commit();
			s.close();
			return li;
		}


		
		
	}
