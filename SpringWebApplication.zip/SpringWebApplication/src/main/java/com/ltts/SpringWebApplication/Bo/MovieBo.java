package com.ltts.SpringWebApplication.Bo;
	import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;

	import com.ltts.SpringWebApplication.model.Movie;

	@Repository
	public class MovieBo {
		@Autowired
		SessionFactory sf;
		public boolean insertMovie(Movie m)throws Exception
		{
			Session s=sf.openSession();
			s.beginTransaction();
			s.save(m);
			s.getTransaction().commit();
			s.close();
			return false;
		}
		public List<Movie> getAllMovies()throws Exception
		{
			List<Movie> li=null;
		
			Session s=sf.openSession();
			s.beginTransaction();
			li=s.createCriteria(Movie.class).list();
			s.getTransaction().commit();
			s.close();
			return li;
		}
		public Movie getMovieById(int id)throws Exception
		{
			List<Movie> li=getAllMovies();
			Movie m=null;
			for(Movie m1:li)
			{
				if(id==m1.getMovieId()) {
				m= new Movie(m1.getMovieId(),m1.getMovieName(),m1.getLanguage(),m1.getReleaseDate(),m1.getDirector());
			}
			}
			return m;
		}
		public List<Movie> getMovieByLanguage(String lang)throws Exception
		{
			List<Movie> li=getAllMovies();
			List<Movie> rli=new ArrayList<Movie>();
			
			//List<Movie> m=null;
			for(Movie m1:li)
			{
				if(lang.equals(m1.getLanguage())) {
					//int movieId, String movieName, String language, LocalDate releaseDate, String director
				rli.add(m1);
			}
			}
			return rli;
		}
		public boolean updateMovie(Movie m)throws Exception
		{
			return false;
		}

	}

